﻿namespace Backend.Service
{
    public class iService
    {
        
    }
}