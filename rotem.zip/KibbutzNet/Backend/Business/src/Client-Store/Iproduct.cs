﻿namespace Backend.Business.src.Client_Store
{
    public interface Iproduct
    {
        
    }
}