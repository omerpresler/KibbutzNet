namespace Backend.Business.src.Client_Store
{
    public class WorkerManager
    {
        
    }
}