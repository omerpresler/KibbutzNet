﻿namespace Backend.Business.Client_Member
{
    public interface Iorder
    {
        
    }
}