namespace Backend.Business.Client_Member
{
    public class Purchase : iPurchase
    {
        
    }
}