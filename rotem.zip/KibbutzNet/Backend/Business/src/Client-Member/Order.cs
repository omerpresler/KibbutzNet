namespace Backend.Business.Client_Member
{
    public class Order : Iorder
    {
    }
}