namespace Backend.Business.Client_Member
{
    public class PurchaseManager : IPurchaseManger
    {
        
    }
}