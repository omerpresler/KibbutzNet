namespace Backend.Business.src.exceptions
{
    public interface IException
    {
        
    }
}