namespace Backend.Business.src.Utils
{
    public class Chat
    {
        
    }
}