namespace Backend.Business.src.Utils
{
    public class Member : User
    {
        private int budgetNumber { get; set; }
    }
}