namespace Backend.Business.src.Utils
{
    public class Outsider : User
    {
        
    }
}