namespace Backend.Business.src.Utils
{
    public abstract class User
    {
        private int storeId;
        private string name;
        private string phoneNumber;
        
    }
}