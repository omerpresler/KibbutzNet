namespace Backend.Business.src.Reports
{
    public class OutputManager
    {
        
    }
}