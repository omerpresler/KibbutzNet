namespace Backend.Business.src.Reports
{
    public class PlainTextReportCreator : ReportCreator
    {
        
    }
}