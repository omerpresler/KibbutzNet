namespace Backend.Business.src.Reports
{
    public class LocalReportSender : ReportSender
    {
        
    }
}