namespace Backend.Business.src.Reports
{
    public class EmailReportCreator : ReportCreator
    {
        
    }
}