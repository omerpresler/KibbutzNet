namespace Backend.Business.src.Reports
{
    public abstract class ReportSender
    {
        
    }
}