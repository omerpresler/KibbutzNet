﻿namespace Backend.Business.src.Facade
{
    public class Facade
    {
        
    }
}